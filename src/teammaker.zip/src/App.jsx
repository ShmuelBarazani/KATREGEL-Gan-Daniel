import React from 'react'
import TeamMaker from './TeamMaker.jsx'

export default function App() {
  return <TeamMaker />
}
