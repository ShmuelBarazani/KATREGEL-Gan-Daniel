\
import React, { useMemo, useRef, useState, useEffect } from "react";
import playersJson from "./players.json"; // ברירת־מחדל מהקובץ המצורף

/* ======== סגנון בסיסי ======== */
const css = {
  page: {
    minHeight: "100vh",
    background: "#0f172a",
    color: "#e5e7eb",
    padding: 0,
    margin: 0,
    fontFamily: "sans-serif",
    direction: "rtl",
  },
  wrap: {
    maxWidth: 1200,
    margin: "0 auto",
    display: "flex",
    flexDirection: "column",
    gap: 12,
    padding: 16,
  },

  /* סרגלים דביקים (עליון/תחתון) */
  barTop: {
    position: "sticky",
    top: 0,
    zIndex: 5,
    background: "#0f172a",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 8,
    flexWrap: "wrap",
    padding: "8px 0",
    borderBottom: "1px solid #113b2c",
  },
  barBottom: {
    position: "sticky",
    bottom: 0,
    zIndex: 5,
    background: "#0f172a",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 8,
    flexWrap: "wrap",
    padding: "8px 0",
    borderTop: "1px solid #113b2c",
  },

  /* אזור רשימת השחקנים – רק הוא גולל */
  middleScroll: { maxHeight: "55vh", overflow: "auto" },

  btn: { padding: "8px 12px", borderRadius: 8, border: "1px solid #065f46", background: "#059669", color: "#fff", cursor: "pointer", whiteSpace: "nowrap" },
  btn2: { padding: "8px 12px", borderRadius: 8, border: "1px solid #065f46", background: "rgba(5,150,105,.15)", color: "#a7f3d0", cursor: "pointer", whiteSpace: "nowrap" },
  btnOutline: { padding: "8px 12px", borderRadius: 8, border: "1px solid #065f46", background: "transparent", color: "#a7f3d0", cursor: "pointer", whiteSpace: "nowrap" },

  card: { background: "#111827", border: "1px solid #1f2937", borderRadius: 12, transition: "box-shadow .15s, border-color .15s" },
  cardDroppable: { background: "#111827", border: "1px solid #34d399", boxShadow: "0 0 0 2px rgba(52,211,153,.35) inset", borderRadius: 12 },
  body: { padding: 12 },

  table: { width: "100%", fontSize: 14, borderCollapse: "collapse" },

  th: {
    position: "sticky",
    top: 0,
    zIndex: 2,
    background: "rgba(6,95,70,.35)",
    color: "#a7f3d0",
    padding: 8,
    textAlign: "right",
    cursor: "pointer",
    whiteSpace: "nowrap",
    backdropFilter: "blur(2px)",
  },

  td: { padding: 8, borderBottom: "1px solid #1f2937", verticalAlign: "middle" },
  input: { background: "#1f2937", color: "#e5e7eb", border: "1px solid #374151", borderRadius: 6, padding: "6px 8px" },
  select: { background: "#1f2937", color: "#e5e7eb", border: "1px solid #374151", borderRadius: 6, padding: "6px 8px" },
  chips: { color: "#a7f3d0", fontSize: 12 },

  modalBg: { position: "fixed", inset: 0, background: "rgba(0,0,0,.6)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 50 },
  modal: { background: "#111827", color: "#e5e7eb", borderRadius: 16, border: "1px solid #1f2937", padding: 24, width: "min(900px, 92vw)" },
};

/* ======== עזרי חישוב ======== */
const POSITIONS = ["", "GK", "DF", "MF", "FW"];
const average = (arr) => (arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : 0);
const targetSizes = (n, k) => { const base = Math.floor(n / k), r = n % k; return Array.from({ length: k }, (_, i) => base + (i < r ? 1 : 0)); };

function teamConstraintCost(team, p) {
  const ids = new Set(team.map((x) => x.id));
  let cost = 0;
  for (const a of p.avoid || []) if (ids.has(a)) cost += 1000;
  let prefer = 0; for (const w of p.prefer || []) if (ids.has(w)) prefer++;
  return cost - prefer * 1;
}
function greedyBalance(players, k) {
  const sizes = targetSizes(players.length, k);
  const teams = Array.from({ length: k }, () => ({ players: [], total: 0 }));
  const sorted = [...players].sort((a, b) => b.r - a.r);
  for (const p of sorted) {
    let best = 0, score = Infinity;
    for (let i = 0; i < k; i++) {
      if (teams[i].players.length < sizes[i]) {
        const s = teams[i].total + teamConstraintCost(teams[i].players, p);
        if (s < score) { score = s; best = i; }
      }
    }
    teams[best].players.push(p); teams[best].total += p.r;
  }
  return teams;
}
function objective(teams) {
  const totals = teams.map(t => t.total), sizes = teams.map(t => t.players.length);
  const tv = average(totals.map(x => (x - average(totals)) ** 2));
  const sv = average(sizes.map(x => (x - average(sizes)) ** 2));
  let pen = 0;
  for (const t of teams) {
    const ids = new Set(t.players.map(p => p.id));
    for (const p of t.players) {
      for (const a of p.avoid || []) if (ids.has(a)) pen += 25;
      let m = 0; for (const w of p.prefer || []) if (ids.has(w)) m++;
      pen -= m * 2;
    }
  }
  return tv + 0.25 * sv + pen;
}
function localImprove(teams, iters = 900) {
  const k = teams.length;
  let best = teams.map(t => ({ players: [...t.players], total: t.total })), bestScore = objective(best);
  for (let it = 0; it < iters; it++) {
    const i = Math.floor(Math.random() * k); let j = Math.floor(Math.random() * k); while (k > 1 && j === i) j = Math.floor(Math.random() * k);
    const ti = best[i], tj = best[j]; if (!ti.players.length || !tj.players.length) continue;
    const ai = Math.floor(Math.random() * ti.players.length), bj = Math.floor(Math.random() * tj.players.length);
    const A = ti.players[ai], B = tj.players[bj];
    ti.players[ai] = B; tj.players[bj] = A; ti.total += B.r - A.r; tj.total += A.r - B.r;
    const s = objective(best);
    if (s > bestScore) { ti.players[ai] = A; tj.players[bj] = B; ti.total += A.r - B.r; tj.total += B.r - A.r; } else bestScore = s;
  }
  return best;
}
function balanceTeams(players, k, mode) {
  if (!players.length || k < 2) return [];
  let t = greedyBalance(players, k);
  if (mode === "Improve") t = localImprove(t, 1200);
  return t;
}
const recomputeTotals = (teams) =>
  teams.map(t => ({ ...t, total: t.players.reduce((s, p) => s + (p.r || 0), 0) }));

/* ======== נירמול ברירת־מחדל מהקובץ ======== */
function normalizeFromJson(list) {
  return (list || []).map((p, i) => ({
    id: Number(p.id ?? i + 1),
    name: String(p.name ?? ""),
    r: Math.max(1, Math.min(10, Number(p.r ?? 5))),
    pos: POSITIONS.includes(p.pos) ? p.pos : "",
    selected: p.selected !== false,
    prefer: Array.isArray(p.prefer) ? p.prefer.map(Number) : [],
    avoid: Array.isArray(p.avoid) ? p.avoid.map(Number) : [],
  }));
}

/* ======== קומפוננטה ======== */
export default function TeamMaker() {
  // טעינה בטוחה מה-localStorage
  const loadPlayersSafe = () => {
    try {
      const raw = localStorage.getItem("teams_players_v20");
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          const norm = normalizeFromJson(parsed);
          if (norm.length) return norm;
        }
      }
    } catch {}
    return normalizeFromJson(playersJson);
  };
  const [players, setPlayers] = useState(loadPlayersSafe);

  const [teamsNum, setTeamsNum] = useState(4); // ברירת מחדל 4
  const [result, setResult] = useState([]);
  const [sortField, setSortField] = useState("name");
  const [sortAsc, setSortAsc] = useState(true);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [linksEditor, setLinksEditor] = useState(null);
  const [showRatings, setShowRatings] = useState(true);

  // === DnD state ===
  const [dragOverTeam, setDragOverTeam] = useState(null); // אינדקס קבוצה שמעליה גוררים

  const fileInputRef = useRef(null);

  // שמירה בטוחה ל-localStorage
  useEffect(() => {
    try {
      localStorage.setItem("teams_players_v20", JSON.stringify(players));
    } catch {}
  }, [players]);

  // ספירת שחקנים מסומנים (ליד מס' קבוצות)
  const selectedCount = useMemo(
    () => players.filter(p => p.selected).length,
    [players]
  );

  /* עוזר: מיון שחקני קבוצה בסדר יורד של r */
  const sortTeamPlayersDesc = (teams) =>
    teams.map(t => ({
      ...t,
      players: [...t.players].sort((a, b) => (b.r || 0) - (a.r || 0)),
    }));

  const run = (forPreview = false) => {
    const pool = players.filter(p => p.selected);
    if (pool.length < teamsNum) {
      setResult([]); // שלא יוצגו תוצאות ישנות
      alert("מס' השחקנים קטן ממס' הקבוצות");
      return;
    }
    let t = balanceTeams(pool, teamsNum, "Improve");
    t = sortTeamPlayersDesc(t);
    setResult(t);
    if (forPreview) setPreviewOpen(true);
  };

  /* ======= שמירת/טעינת שחקנים ======= */
  const exportPlayers = () => {
    const blob = new Blob([JSON.stringify(players, null, 2)], { type: "application/json;charset=utf-8" });
    const url = URL.createObjectURL(blob); const a = document.createElement("a");
    a.href = url; a.download = "players.json"; document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 0);
  };
  const importPlayers = async (file) => {
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      if (!Array.isArray(parsed)) return alert("קובץ לא תקין (ציפינו למערך).");
      const normalized = normalizeFromJson(parsed);
      if (!normalized.length) return alert("קובץ לא תקין או ריק.");
      setResult([]); setPlayers(normalized); alert("הרשימה נטענה בהצלחה.");
    } catch { alert("שגיאה בקריאת הקובץ (JSON)."); }
  };

  /* ======= העתקות/הורדות תוצאות ======= */
  const copyWithRatings = () => {
    if (!result.length) return navigator.clipboard.writeText("");
    const text = result.map((t, i) =>
      `קבוצה ${i + 1}: ${t.players.map(p => `${p.name} (${p.r}${p.pos ? ", " + p.pos : ""})`).join(", ")} | סכום: ${t.players.reduce((s,x)=>s+(x.r||0),0)} | ממוצע: ${(t.players.reduce((s,x)=>s+(x.r||0),0)/Math.max(1,t.players.length)).toFixed(2)}`
    ).join("\n");
    navigator.clipboard.writeText(text);
  };
  const copyNamesOnly = () => {
    if (!result.length) return navigator.clipboard.writeText("");
    const text = result.map((t, i) => `קבוצה ${i + 1}: ${t.players.map(p => p.name).join(", ")}`).join("\n");
    navigator.clipboard.writeText(text);
  };
  const downloadNamesOnly = () => {
    let t = result;
    if (!t || !t.length) {
      const pool = players.filter(p => p.selected);
      if (pool.length >= teamsNum) t = balanceTeams(pool, teamsNum, "Improve");
      else { alert("אין תוצאות. לחץ 'עשה כוחות' או בחר יותר שחקנים."); return; }
    }
    const text = t.map((team, i) => `קבוצה ${i + 1}: ${team.players.map(p => p.name).join(", ")}`).join("\n");
    const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob); const a = document.createElement("a");
    a.href = url; a.download = "כוחות_קטרגל.txt"; document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 0);
  };

  /* ======= שימושיות בטבלה ======= */
  const resetDefaults = () => {
    try { localStorage.removeItem("teams_players_v20"); } catch {}
    setPlayers(normalizeFromJson(playersJson));
    setResult([]);
  };
  const update = (id, field, value) => setPlayers(ps => ps.map(p => p.id === id ? { ...p, [field]: value } : p));
  const remove = (id) => setPlayers(ps => ps.filter(p => p.id !== id));
  const add = () => { const nid = players.reduce((m, p) => Math.max(m, p.id), 0) + 1; setPlayers([...players, { id: nid, name: "חדש", r: 5, pos: "", selected: true, prefer: [], avoid: [] }]); };

  const sortBy = (field) => {
    const asc = sortField === field ? !sortAsc : true;
    setSortField(field); setSortAsc(asc);
    setPlayers(ps => [...ps].sort((a, b) => (a[field] < b[field] ? (asc ? -1 : 1) : a[field] > b[field] ? (asc ? 1 : -1) : 0)));
  };
  const SortIcon = ({ field }) => (sortField === field ? (sortAsc ? " ▲" : " ▼") : "");

  const namesById = useMemo(() => { const m = new Map(); players.forEach(p => m.set(p.id, p.name)); return m; }, [players]);
  const labelList = (ids) => { if (!ids || !ids.length) return "—"; const n = ids.map(id => namesById.get(id) || id).slice(0, 2).join(", "); return ids.length > 2 ? `${n} +${ids.length - 2}` : n; };

  /* ======= עריכת קבוצות לאחר ההגרלה ======= */
  const movePlayerToTeam = (fromIdx, playerId, toIdx) => {
    if (fromIdx === toIdx) return;
    setResult((prev) => {
      if (!Array.isArray(prev) || !prev.length) return prev;
      const teams = prev.map(t => ({ ...t, players: [...t.players] }));
      const from = teams[fromIdx], to = teams[toIdx];
      if (!from || !to) return prev;

      const pIndex = from.players.findIndex(p => p.id === playerId);
      if (pIndex === -1) return prev;
      const [p] = from.players.splice(pIndex, 1);
      to.players.push(p);

      const sorted = teams.map(t => ({ ...t, players: t.players.sort((a,b)=> (b.r||0)-(a.r||0)) }));
      return recomputeTotals(sorted);
    });
  };

  // === HTML5 Drag & Drop ===
  const onDragStart = (e, fromIdx, playerId) => {
    try {
      e.dataTransfer.setData("application/json", JSON.stringify({ fromIdx, playerId }));
      e.dataTransfer.effectAllowed = "move";
    } catch {}
  };
  const onDragOverTeam = (e, teamIdx) => {
    e.preventDefault(); // מאפשר drop
    if (dragOverTeam !== teamIdx) setDragOverTeam(teamIdx);
  };
  const onDragLeaveTeam = (_e, teamIdx) => {
    if (dragOverTeam === teamIdx) setDragOverTeam(null);
  };
  const onDropOnTeam = (e, toIdx) => {
    e.preventDefault();
    try {
      const data = JSON.parse(e.dataTransfer.getData("application/json") || "{}");
      if (typeof data.fromIdx === "number" && typeof data.playerId !== "undefined") {
        movePlayerToTeam(Number(data.fromIdx), Number(data.playerId), Number(toIdx));
      }
    } catch {}
    setDragOverTeam(null);
  };

  /* ======= רכיבי UI ======= */
  const TeamsInput = () => (
    <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
      <span style={{ fontSize: 12, color: "#a7f3d0" }}>מס' קבוצות</span>
      <input
        type="number"
        min={2}
        max={12}
        value={teamsNum}
        onChange={(e)=>setTeamsNum(Math.max(2, Number(e.target.value)||2))}
        style={{ ...css.input, width: 70 }}
      />
      <span style={{ fontSize: 12, color: "#9ae6b4" }}>
        ({selectedCount} שחקנים מסומנים)
      </span>
    </div>
  );

  const ToggleRatingsBtn = () => (
    <button style={css.btn2} onClick={() => setShowRatings((v) => !v)}>
      {showRatings ? "הצג ללא ציונים" : "הצג עם ציונים"}
    </button>
  );

  const TopBar = () => (
    <div style={css.barTop}>
      <h1 style={{ color: "#34d399", fontWeight: 700, margin: 0 }}>קטרגל גן דניאל ⚽</h1>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
        <button style={css.btn} onClick={() => run(false)}>עשה כוחות</button>
        <ToggleRatingsBtn />
        <button style={css.btn2} onClick={copyWithRatings}>העתק עם ציונים</button>
        <button style={css.btn2} onClick={copyNamesOnly}>העתק ללא ציונים</button>
        <button style={css.btn2} onClick={downloadNamesOnly}>הורד TXT</button>
        <button style={css.btn2} onClick={exportPlayers}>שמירת שחקנים</button>

        <input
          ref={fileInputRef}
          type="file"
          accept="application/json"
          style={{ display: "none" }}
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) importPlayers(f).finally(() => (e.target.value = ""));
          }}
        />
        <button style={css.btn2} onClick={() => fileInputRef.current?.click()}>טעינת שחקנים</button>

        <button style={css.btn} onClick={() => run(true)}>PREVIEW</button>
        <button style={css.btnOutline} onClick={resetDefaults}>אפס ברירת־מחדל</button>
        <button style={css.btn} onClick={add}>הוסף שחקן</button>

        <TeamsInput />
      </div>
    </div>
  );

  const BottomBar = () => (
    <div style={css.barBottom}>
      <div />
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
        <button style={css.btn} onClick={() => run(false)}>עשה כוחות</button>
        <ToggleRatingsBtn />
        <button style={css.btn2} onClick={copyWithRatings}>העתק עם ציונים</button>
        <button style={css.btn2} onClick={copyNamesOnly}>העתק ללא ציונים</button>
        <button style={css.btn2} onClick={downloadNamesOnly}>הורד TXT</button>
        <button style={css.btn2} onClick={exportPlayers}>שמירת שחקנים</button>
        <button style={css.btn2} onClick={() => fileInputRef.current?.click()}>טעינת שחקנים</button>
        <TeamsInput />
      </div>
    </div>
  );

  // שורת כפתורים מעל הקבוצות שנוצרו
  const GroupsActionsBar = () => (
    <div style={{
      display: "flex",
      gap: 8,
      flexWrap: "wrap",
      alignItems: "center",
      margin: "0 0 12px 0"
    }}>
      <button style={css.btn} onClick={() => run(false)}>עשה כוחות</button>
      <button style={css.btn2} onClick={() => setShowRatings(v => !v)}>
        {showRatings ? "הצג ללא ציונים" : "הצג עם ציונים"}
      </button>
      <button style={css.btn2} onClick={copyWithRatings}>העתק עם ציונים</button>
      <button style={css.btn2} onClick={copyNamesOnly}>העתק ללא ציונים</button>
      <button style={css.btn2} onClick={downloadNamesOnly}>הורד TXT</button>
      <button style={css.btn2} onClick={exportPlayers}>שמירת שחקנים</button>
      <button style={css.btn2} onClick={() => fileInputRef.current?.click()}>טעינת שחקנים</button>
    </div>
  );

  const playerLineText = (p) =>
    `${p.name} (${p.pos || "-"})${showRatings ? ` – ${p.r}` : ""}`;

  // אלמנט שחקן גריר
  const DraggablePlayer = ({ p, teamIdx }) => (
    <li
      key={p.id}
      draggable
      onDragStart={(e) => onDragStart(e, teamIdx, p.id)}
      style={{
        display: "flex",
        alignItems: "center",
        gap: 6,
        margin: "4px 0",
        fontSize: 13,
        whiteSpace: "nowrap",
        cursor: "grab",
      }}
      title={playerLineText(p)}
    >
      <span
        style={{
          flex: 1,
          overflow: "hidden",
          textOverflow: "ellipsis",
          whiteSpace: "nowrap",
        }}
      >
        {playerLineText(p)}
      </span>

      {/* עדיין משאיר את התיבה להעברה מהירה למי שמעדיף */}
      <select
        style={{ ...css.select, width: 72, paddingInline: 6, fontSize: 12 }}
        value={teamIdx}
        onChange={(e) => movePlayerToTeam(teamIdx, p.id, Number(e.target.value))}
        title="העבר לקבוצה"
      >
        {result.map((_, i) => (
          <option key={i} value={i}>קבוצה {i + 1}</option>
        ))}
      </select>
    </li>
  );

  // קארד קבוצה עם Drop
  const TeamCard = ({ t, idx }) => {
    const total = t.players.reduce((s, x) => s + (x.r || 0), 0);
    const avg = (total / Math.max(1, t.players.length)).toFixed(2);

    return (
      <div
        style={dragOverTeam === idx ? css.cardDroppable : css.card}
        onDragOver={(e) => onDragOverTeam(e, idx)}
        onDragLeave={(e) => onDragLeaveTeam(e, idx)}
        onDrop={(e) => onDropOnTeam(e, idx)}
      >
        <div style={{ ...css.body, padding: 16 }}>
          <h3 style={{ fontWeight: 700, color: "#6ee7b7" }}>קבוצה {idx + 1}</h3>
          <ul style={{ paddingInlineStart: 0, listStyle: "none", margin: 0 }}>
            {t.players.map((p) => (
              <DraggablePlayer key={p.id} p={p} teamIdx={idx} />
            ))}
          </ul>

          {showRatings && (
            <div style={{ fontSize: 13, color: "#a7f3d0", marginTop: 6 }}>
              סכ"ה: {total} | ממוצע: {avg}
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <div style={css.page}>
      <div style={css.wrap}>

        {/* סרגל עליון */}
        <TopBar />

        {/* רשימת השחקנים – גוללת בלבד */}
        <div style={css.middleScroll}>
          <div style={css.card}>
            <div style={css.body}>
              <table style={css.table}>
                <thead>
                  <tr>
                    <th style={css.th} onClick={() => sortBy("selected")}>משחק?<SortIcon field="selected" /></th>
                    <th style={{ ...css.th, width: 180 }} onClick={() => sortBy("name")}>שם<SortIcon field="name" /></th>
                    <th style={css.th} onClick={() => sortBy("pos")}>עמדה<SortIcon field="pos" /></th>
                    <th style={css.th} onClick={() => sortBy("r")}>ציון<SortIcon field="r" /></th>
                    <th style={css.th}>חייב עם</th>
                    <th style={css.th}>לא עם</th>
                    <th style={css.th}></th>
                  </tr>
                </thead>
                <tbody>
                  {players.map(p => (
                    <tr key={p.id}>
                      <td style={css.td}><input type="checkbox" checked={p.selected} onChange={e => update(p.id, "selected", e.target.checked)} /></td>
                      <td style={css.td}><input style={{ ...css.input, width: 170 }} value={p.name} onChange={e => update(p.id, "name", e.target.value)} /></td>
                      <td style={css.td}>
                        <select style={css.select} value={p.pos} onChange={e => update(p.id, "pos", e.target.value)}>
                          {POSITIONS.map(pp => <option key={pp} value={pp}>{pp || "(ללא)"}</option>)}
                        </select>
                      </td>
                      <td style={css.td}>
                        <input style={{ ...css.input, width: 70 }} type="number" min={1} max={10}
                               value={p.r} onChange={e => update(p.id, "r", Math.max(1, Math.min(10, Number(e.target.value))))} />
                      </td>
                      <td style={css.td}>
                        <span style={css.chips} title={(p.prefer || []).map(id => namesById.get(id)).join(", ") || ""}>{labelList(p.prefer)}</span>
                        <button style={{ ...css.btn2, marginInlineStart: 8 }} onClick={() => setLinksEditor({ id: p.id, prefer: p.prefer || [], avoid: p.avoid || [] })}>ערוך</button>
                      </td>
                      <td style={css.td}>
                        <span style={css.chips} title={(p.avoid || []).map(id => namesById.get(id)).join(", ") || ""}>{labelList(p.avoid)}</span>
                        <button style={{ ...css.btn2, marginInlineStart: 8 }} onClick={() => setLinksEditor({ id: p.id, prefer: p.prefer || [], avoid: p.avoid || [] })}>ערוך</button>
                      </td>
                      <td style={css.td}><button style={css.btnOutline} onClick={() => remove(p.id)}>מחק</button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* סרגל תחתון */}
        <BottomBar />

      </div>

      {/* כותרת + פעולות מעל רשימת הקבוצות */}
      {result.length > 0 && (
        <div style={{ maxWidth: 1200, margin: "8px auto 0", padding: "0 16px" }}>
          <h1 style={{ color: "#34d399", fontWeight: 700, margin: "8px 0 12px" }}>קטרגל גן דניאל ⚽</h1>
          <GroupsActionsBar />
        </div>
      )}

      {/* תוצאות הקבוצות – מתחת לסרגל התחתון */}
      {result.length > 0 && (
        <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 16px 24px 16px" }}>
          <div style={{ display: "grid", gap: 16, gridTemplateColumns: "repeat(auto-fit,minmax(260px,1fr))" }}>
            {result.map((t, idx) => (
              <TeamCard key={idx} t={t} idx={idx} />
            ))}
          </div>
        </div>
      )}

      {/* PREVIEW */}
      {previewOpen && (
        <div style={css.modalBg}>
          <div style={css.modal}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12 }}>
              <h2 style={{ fontWeight: 700, color: "#34d399" }}>תצוגת PREVIEW</h2>
              <div style={{ display: "flex", gap: 8 }}>
                <button style={css.btn2} onClick={() => setPreviewOpen(false)}>סגור</button>
                <button style={css.btn} onClick={() => { setPreviewOpen(false); run(false); }}>אשר והצג בעמוד</button>
              </div>
            </div>
            {result.length === 0 ? (
              <div style={{ fontSize: 14, color: "#d1d5db" }}>אין תוצאות – לחץ על PREVIEW שוב.</div>
            ) : (
              <div style={{ display: "grid", gap: 16, gridTemplateColumns: "repeat(auto-fit,minmax(260px,1fr))" }}>
                {result.map((t, idx) => (
                  <TeamCard key={`pv-${idx}`} t={t} idx={idx} />
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* מודל "חייב עם / לא עם" */}
      {linksEditor && (
        <div style={css.modalBg}>
          <div style={css.modal}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12 }}>
              <h2 style={{ fontWeight: 700, color: "#34d399" }}>שיוך שחקנים</h2>
            </div>
            {(() => {
              const pid = linksEditor.id;
              const others = players.filter(x => x.id !== pid);
              return (
                <div style={{ display: "grid", gap: 16, gridTemplateColumns: "repeat(auto-fit,minmax(280px,1fr))" }}>
                  <div>
                    <div style={{ fontWeight: 600, color: "#6ee7b7", marginBottom: 6 }}>חייב לשחק עם</div>
                    <select multiple style={{ ...css.select, width: "100%", height: 220 }}
                            value={linksEditor.prefer}
                            onChange={e => setLinksEditor({ ...linksEditor, prefer: Array.from(e.target.selectedOptions).map(o => Number(o.value)) })}>
                      {others.map(x => <option key={x.id} value={x.id}>{x.name}</option>)}
                    </select>
                  </div>
                  <div>
                    <div style={{ fontWeight: 600, color: "#6ee7b7", marginBottom: 6 }}>לא לשחק עם</div>
                    <select multiple style={{ ...css.select, width: "100%", height: 220 }}
                            value={linksEditor.avoid}
                            onChange={e => setLinksEditor({ ...linksEditor, avoid: Array.from(e.target.selectedOptions).map(o => Number(o.value)) })}>
                      {others.map(x => <option key={x.id} value={x.id}>{x.name}</option>)}
                    </select>
                  </div>
                </div>
              );
            })()}
            <div style={{ display: "flex", gap: 8, marginTop: 16, justifyContent: "flex-end" }}>
              <button style={css.btn2} onClick={() => setLinksEditor(null)}>סגור</button>
              <button
                style={css.btn}
                onClick={() => {
                  const { id, prefer, avoid } = linksEditor;
                  setPlayers(ps => ps.map(p => p.id === id ? { ...p, prefer, avoid } : p));
                  setLinksEditor(null);
                }}
              >
                שמור
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
