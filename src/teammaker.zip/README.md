# קטרגל גן דניאל ⚽

אפליקציית React (Vite) להרכבת קבוצות, כולל גרירת שחקנים בין קבוצות (HTML5 Drag & Drop).

## הרצה מקומית
```bash
npm install
npm run dev
```
הכנס לכתובת שמודפסת בטרמינל (לרוב `http://localhost:5173/`).

## קבצים חשובים
- `src/TeamMaker.jsx` — הקומפוננטה המרכזית (גרסה 1).
- `src/players.json` — רשימת שחקנים לדוגמה. ניתן לערוך/להחליף.

## Build
```bash
npm run build
npm run preview
```
